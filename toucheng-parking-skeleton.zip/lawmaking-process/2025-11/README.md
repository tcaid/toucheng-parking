# 2025-11 修法卷宗
請置放：
- comparative-matrix_A3.pdf（全縣/鄉鎮對照）
- town-vs-county_A4.docx（頭城 vs 縣級 三欄對照）
- general-explanation.docx（修正總說明）
- article-by-article.docx（逐條修正理由書）
- meeting-minutes/（會議紀錄與簡報）

狀態欄：
- 版次：v1（初稿）
- 審議：未審/已審/退回修正
- 備註：
