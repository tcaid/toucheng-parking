# 變更紀錄（CHANGELOG）

## 2025-10-31
- 初始化專案骨架與 GitHub Pages 首頁
- 建立固定連結策略（docs/files/latest/）
- 新增資料夾：regulations/、lawmaking-process/、references/、datasets/、templates/
