# 資料集（datasets）
- fee-schedule.csv：各級費率、時段、月票占比（欄位見下）
- parking-lots.geojson：場站定位（若有）

## fee-schedule.csv 欄位建議
jurisdiction, level, vehicle_type, unit, day_rate, night_rate, free_grace_minutes, monthly_cap, monthly_quota_ratio
ex: "宜蘭縣","丁","小型車","hour","40","30","10","—","—"
